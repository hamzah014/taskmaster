@extends('layouts.app')

@push('css')
    <style>
    </style>
@endpush
@section('content')


<div id="kt_app_content_container" class="app-container d-flex justify-content-center align-items-center">
	<div class="card mb-5 mb-xl-10 bg-transparent card-no-border w-100">
		<div id="kt_account_settings_profile_details">
			<div class="card-body p-9">

        <div class="row flex-row mb-5 card bg-light h-100px p-10">
            <div class="col-md-12">
                <h2>You have dont have access. Please contact administrator system. </h2>
            </div>
        </div>
				
			</div>
		</div>
	</div>
</div>

@endsection
@push('script')
@endpush
