<!-- Pre Loader Start  -->
<div class="load" style=" background: none repeat scroll 0 0 rgba(0, 0, 0, 0.5);
    height: 100%;
    left: 0;
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 9999 !important;">
        <div class="loadscreen">
                <div class="loader"></div>
        </div>
</div>

<!-- Pre Loader end  -->