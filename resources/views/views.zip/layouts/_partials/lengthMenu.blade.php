language : {
		search :  "{{trans('datatable.General.search')}}",
		searchPlaceholder : "{{trans('datatable.General.searchPlaceholder')}}",
		zeroRecords: "{{trans('datatable.General.zeroRecords')}}",
		emptyTable:  "{{trans('datatable.General.emptyTable')}}",
		info : "{{trans('datatable.General.info')}}",
		infoEmpty : "{{trans('datatable.General.infoEmpty')}}",
		infoPostFix : "",
		infoFiltered : "",
		processing : "{{trans('datatable.General.processing')}}",
		loadingRecords : "{{trans('datatable.General.loadingRecords')}}",
		paginate : {
			first :    "{{trans('datatable.General.start')}}",
			last :     "{{trans('datatable.General.end')}}",
			previous : "{{trans('datatable.General.previous')}}",
			next :     "{{trans('datatable.General.next')}}"
		},
		lengthMenu: "{{trans('datatable.General.lengthMenu')}}",
	
},