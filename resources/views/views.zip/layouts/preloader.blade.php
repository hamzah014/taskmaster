<!-- Pre Loader Start  -->

<div class="page-loader flex-column bg-light bg-opacity-75">
        <div class="darksoul-layout">
                <div class="darksoul-grid">
                        <div class="item1"></div>
                        <div class="item2"></div>
                        <div class="item3"></div>
                        <div class="item4"></div>
                </div>
                <h3 class="darksoul-loader-h">CollabTech</h3>
        </div>
</div>

<!-- Pre Loader end  -->
